%Load motion profiles
load NW2_20_RepSignals

ref1=[TDisp Disp];
ref1dot=[TDisp DispDot];
ref1ddot=[TDisp DispDDot];

ref2=[THAng HAng];
ref2dot=[THAng HAngDot];
ref2ddot=[THAng HAngDDot];

ref3=[TKAng KAng];
ref3dot=[TKAng KAngDot];
ref3ddot=[TKAng KAngDDot];

%Z0=[0.01913;1.1317;0.0925;0.09324;0;0]; %initial condition for plant integrator
Z0 = [0.01913 ; 1.1317 ; 0.0925 ; 0.09324 ; 0 ; 1.6]; %initial condition for plant integrator
Ts=5e-4; % integration step size
mu=0.2;

% Kalman filter parameters
Qtrue = Ts * [0 ; 0 ; 0 ; 0.01^2 ; 0.002^2 ; 0.002^2]; % diagonal elements of process noise covariance
Qfilter = Ts * 10000 * [0.1 ; 1 ; 1 ; 0.01 ; 0.01 ; 0.01]; % filter-assumed elements of process noise covariance 
P0 = [1e-4 ; 1e-4 ; 1e-4 ; 0.1 ; 0.1 ; 0.1]; % diagonal elements of initial Kalman filter estimation error covariance

% Select the number of measurements, the corresponding measurement matrix, and the measurement noise covariance
% Note that the corresponding plotting routines in the Simulink model need to be commented out to be consistent with the following choice

% NumMeas = 3;
% H = [eye(3), zeros(3, 3)]; % measurement matrix: vertical hip position, thigh angle, knee angle
% R = [0.001^2 ; 0.01^2 ; 0.01^2]; % diagonal elements of measurement noise covariance: meters^2, rad^2, rad^2
% 
% NumMeas = 2;
% H = [0 1 0 0 0 0 ; 0 0 1 0 0 0]; % thigh angle, knee angle
% R = [0.01^2 ; 0.01^2];

NumMeas = 1;
H = [0 0 1 0 0 0]; % knee angle
R = 0.01^2;

H = reshape(H, numel(H), 1);