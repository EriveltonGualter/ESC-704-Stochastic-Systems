function LZ=end_Z(u)
%Calculates the vertical position of the load cell in the world frame
l3=0.527; 
l2=0.425;
%Parse inputs
q1=u(1);
q2=u(2);
q3=u(3);

LZ=l3*sin(q2+q3)+l2*sin(q2)+q1;
