function zdot=statederCCFforce(z, u, fe, Qvector)
%CCF robot w/o active joint dynamics
%Assumes semiactive electromechanical joint on knee
%u1 is the active control force for hip
%u2 is the active control torque for thigh
%u3 is the active control torque for knee

%fe is [fx fz], the horizontal and vertical external forces acting at the
%end of the shank 

%Baseline parameters
%Mass of link 1: m1
m1=40.5969; %in kg, this is the linearly-moving mass of link 1
%Mass of link 2: m2
m2=8.5731; %in kg, mass of green plate, screws, threaded rod (thigh) and connecting hardware
%Mass of link 3: m3
m3=2.29; %in kg, mass below the knee, including Mauch knee, ankle/foot and shoe
%Equiv. sliding friction in link 1:
f=83.33; %in N

%Rotary actuator damping:
b=9.75; %in N-m-s

%Dimensional parameters of link 2:
l2=0.425; %in m, nominal thigh length
%c2=-0.339; %in m, calculated in SolidWorks
c2=0.09; %CORRECTED FROM MCE647 COORD SYST AND PARS
%(old c1 value)
%Dimensional parameters of link 3:
l3=0.527; %in m, overall length of L3, from knee joint to load cell on shoe
c3=0.32; %in m, distance from knee joint to L3 CG including shoe
%Rotary inertia of link 2:
I2z=0.105+0.33;%in kg-m^2, includes green plate, threaded rod and connecting hardware.
%Rotary inertia of link 3:
I3z=0.0618; %in kg-m^2, overall inertia of L3 with shoe, relative to cm
g=9.81; %acceleration of gravity, m/s^2


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

TH1= m1+m2+m3;
TH2= m3*l2+m2*l2+m2*c2;
TH3= c3*m3;
TH4= I2z + I3z + c2^2*m2 + c3^2*m3 + l2^2*m2 + l2^2*m3 + 2*c2*l2*m2;
TH5= l2*m3*c3;
TH6= m3*c3^2 + I3z;
TH7= b;
TH8= f;

%TH=[TH1;TH2;TH3;TH4;TH5;TH6;TH7;TH8;TH9];


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Parse inputs
n=length(z);
z_1=z(1:n/2);
z_2=z(n/2+1:n);
q1=z_1(1);q2=z_1(2);q3=z_1(3);
q1dot=z_2(1);q2dot=z_2(2);q3dot=z_2(3);

M(1,1)=TH1;
M(1,2)=TH3*cos(q2 + q3) + TH2*cos(q2);
M(1,3)=TH3*cos(q2 + q3);
M(2,1)=M(1,2);
M(2,2)=TH4 + 2*TH5*cos(q3);
M(2,3)=TH6 + TH5*cos(q3);
M(3,1)=M(1,3);
M(3,2)=M(2,3);
M(3,3)=TH6;

C(1,1)=0;
C(1,2)=-q2dot*(TH3*sin(q2 + q3)+TH2*sin(q2))-TH3*q3dot*sin(q2 + q3);
C(1,3)=- TH3*q2dot*sin(q2 + q3) - TH3*q3dot*sin(q2 + q3);
C(2,1)=0;
C(2,2)=-TH5*q3dot*sin(q3);
C(2,3)=- TH5*q2dot*sin(q3) - TH5*q3dot*sin(q3);
C(3,1)=0;
C(3,2)=TH5*q2dot*sin(q3);
C(3,3)=0;

gg=[-g*TH1;-g*(TH2*cos(q2)+TH3*cos(q2+q3));-g*TH3*cos(q2+q3)];

%External force terms
fex=fe(1);fez=fe(2);
Te=[fez; fez*(l3*cos(q2+q3)+l2*cos(q2))-fex*(l3*sin(q2+q3)+l2*sin(q2));l3*(fez*cos(q2+q3)-fex*sin(q2+q3))];

%R=[TH8*sign(q1dot);TH7*q2dot;0];
sign_q1dot = (1 - exp(-10*q1dot)) / (1 + exp(-10*q1dot));
R = [TH8*sign_q1dot ; TH7*q2dot ; 0];

zdot=[z_2;M\(u-R-C*z_2-gg-Te);Te];

zdot(1:n) = zdot(1:n) + sqrt(Qvector) .* randn(n,1); % add random noise to the state derivatives




      



    