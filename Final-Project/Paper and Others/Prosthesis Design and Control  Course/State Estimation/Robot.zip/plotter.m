figure
subplot(2,2,1);
plot(t,q1d,t,q1)
grid on
xlabel('Time (s)')
ylabel('')
title('Hip Displacement')
legend('q1d','q1')
subplot(2,2,2);
 
plot(t,q2d,t,q2)
grid on
xlabel('Time (s)')
ylabel('')
title('Hip Angle')
legend('q2d','q2')

subplot(2,2,3);

 
plot(t,q3d,t,q3)
grid on
xlabel('Time (s)')
ylabel('')
title('Knee Angle')
legend('q3d','q3')

figure
subplot(2,2,1);
plot(t,(q1d-q1).^2)
grid on
xlabel('Time (s)')
ylabel('')
title('square-error for q1')

subplot(2,2,2);
plot(t,(q2d-q2).^2)
grid on
xlabel('Time (s)')
ylabel('')
title('square-error for q2')

subplot(2,2,3);
plot(t,(q3d-q3).^2)
grid on
xlabel('Time (s)')
ylabel('')
title('square-error for q3')



figure 
subplot(2,2,1);
plot(t,Fx)
grid on
xlabel('Time (s)')
ylabel('')
title('Fx')



subplot(2,2,2);
plot(t,Fz)
grid on
xlabel('Time (s)')
ylabel('')
title('Fz')




figure
subplot(2,2,1);
plot(t,u(:,1))
grid on
xlabel('Time (s)')
ylabel('')
title('u1')

subplot(2,2,2); 
plot(t,u(:,2))
grid on
xlabel('Time (s)')
ylabel('')
title('u2')


subplot(2,2,3);
plot(t,u(:,3))
grid on
xlabel('Time (s)')
ylabel('')
title('u3')





