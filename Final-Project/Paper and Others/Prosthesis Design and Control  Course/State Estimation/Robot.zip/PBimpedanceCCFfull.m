function uA=PBimpedanceCCFfull(z,zd,Te,zi)
%Impedance approach

%Baseline parameters
%Mass of link 1: m1
m1=40.5969; %in kg, this is the linearly-moving mass of link 1
%Mass of link 2: m2
m2=8.5731; %in kg, mass of green plate, screws, threaded rod (thigh) and connecting hardware
%Mass of link 3: m3
m3=2.29; %in kg, mass below the knee, including Mauch knee, ankle/foot and shoe
%Equiv. sliding friction in link 1:
f=83.33; %in N
%Rotary actuator damping:
b=9.75; %in N-m-s
%Dimensional parameters of link 2:
l2=0.425; %in m, nominal thigh length
%c2=-0.339; %in m, calculated in SolidWorks
c2=0.09; %CORRECTED FROM MCE647 COORD SYST AND PARS
%(c1 value)
%Dimensional parameters of link 3:
l3=0.527; %in m, overall length of L3, from knee joint to load cell on shoe
c3=0.32; %in m, distance from knee joint to L3 CG including shoe
%Rotary inertia of link 2:
I2z=0.105+0.33;%in kg-m^2, includes green plate, threaded rod and connecting hardware.
%Rotary inertia of link 3:
I3z=0.0618; %in kg-m^2, overall inertia of L3 with shoe, relative to cm
g=9.81; %acceleration of gravity, m/s^2

TH1= m1+m2+m3;
TH2= m3*l2+m2*l2+m2*c2;
TH3= c3*m3;
TH4= I2z + I3z + c2^2*m2 + c3^2*m3 + l2^2*m2 + l2^2*m3 + 2*c2*l2*m2;
TH5= l2*m3*c3;
TH6= m3*c3^2 + I3z;
TH7= b;
TH8= f;


TH=[TH1;TH2;TH3;TH4;TH5;TH6;TH7;TH8];
g=9.81;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
q1=z(1);
q2=z(2);
q3=z(3);
q1dot=z(4);
q2dot=z(5);
q3dot=z(6);

q1d=zd(1);
q2d=zd(4);
q3d=zd(7);
q1ddot=zd(2);
q2ddot=zd(5);
q3ddot=zd(8);
q1dddot=zd(3);
q2dddot=zd(6);
q3dddot=zd(9);

qtilde=[q1-q1d;q2-q2d;q3-q3d];
qtildedot=[q1dot-q1ddot;q2dot-q2ddot;q3dot-q3ddot];

%Gains
L=diag([10 3 10]);
K=diag([10 5 5]);

%Desired Impedance
Ib=0.01;
Bb=50;
Kb=200;
Fr=inv(Ib);
A=-20;
Kp=Kb+A*Ib*L(3,3);
Kd=Bb-Ib*L(3,3)+A*Ib;
Kf=1;

%knee
zidot=A*zi+Kp*qtilde(3)+Kd*qtildedot(3)+Kf*Te(3);
v_IM=q3ddot-L(3,3)*qtilde(3)-Fr*zi;
a_IM=q3dddot-L(3,3)*qtildedot(3)-Fr*zidot;
r_IM=qtildedot(3)+L(3,3)*qtilde(3)+Fr*zi;

%hip
v_PB=[q1ddot;q2ddot;q3ddot]-L*qtilde;
a_PB=[q1dddot;q2dddot;q3dddot]-L*qtildedot;
r_PB=qtildedot+L*qtilde;

r=[r_PB(1);r_PB(2);r_IM];

a1=a_PB(1);a2=a_PB(2);a3=a_IM;
v1=v_PB(1);v2=v_PB(2);v3=v_IM;

Ya(1,1)=a1 - g;
Ya(1,2)=a2*cos(q2) - q2dot*v2*sin(q2);
Ya(1,3)=-(q2dot+q3dot)*(v2+v3)*sin(q2+q3)+cos(q2+q3)*(a2+a3);
Ya(1,4)=0;
Ya(1,5)=0;
Ya(1,6)=0;
Ya(1,7)=0;
Ya(1,8)=sign(v1);%q1dot);

Ya(2,1)=0;
Ya(2,2)=a1*cos(q2) - g*cos(q2);
Ya(2,3)=cos(q2+q3)*(a1-g);
Ya(2,4)=a2;
Ya(2,5)=(2*a2+a3)*cos(q3)-(q2dot*v3+v2*q3dot+q3dot*v3)*sin(q3);
Ya(2,6)=a3;
Ya(2,7)=v2;%q2dot;
Ya(2,8)=0;

Ya(3,1)=0;
Ya(3,2)=0;
Ya(3,3)=Ya(2,3);
Ya(3,4)=0;
Ya(3,5)=sin(q3)*q2dot*v2 + a2*cos(q3);
Ya(3,6)=a2+a3;
Ya(3,7)=0;
Ya(3,8)=0;

Ya_3=[0,0,Ya(2,3),0,sin(q3)*q2dot*v2 + a2*cos(q3),a2+a3,0,0];

u_PB=Ya*TH-K*r_PB+Te;
u_PB=[u_PB(1);u_PB(2)];
u_IM=Ya_3*TH-K(3)*r_IM+Te(3);
u=[u_PB;u_IM];

uA=[u;zidot;r];