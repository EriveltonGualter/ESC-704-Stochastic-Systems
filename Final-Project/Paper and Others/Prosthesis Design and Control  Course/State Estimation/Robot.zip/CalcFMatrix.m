function F = CalcFMatrix

% Symbolically calculate the partial derivative of f(x,u) with respect to x, where xdot = f(x,u)
% The output of this function is cut-and-pasted into function EvaluateFMatrix.m

syms q1 q2 q3 q1dot q2dot q3dot fex fez u1 u2 u3
qdot = [q1dot; q2dot; q3dot];
u = [u1; u2; u3];

%Baseline parameters - THESE HAVE TO MATCH THE PARAMETERS IN statederCCFforce.M
%Mass of link 1: m1
m1=40.5969; %in kg, this is the linearly-moving mass of link 1
%Mass of link 2: m2
m2=8.5731; %in kg, mass of green plate, screws, threaded rod (thigh) and connecting hardware
%Mass of link 3: m3
m3=2.29; %in kg, mass below the knee, including Mauch knee, ankle/foot and shoe
%Equiv. sliding friction in link 1:
f=83.33; %in N

%Rotary actuator damping:
b=9.75; %in N-m-s

%Dimensional parameters of link 2:
l2=0.425; %in m, nominal thigh length
%c2=-0.339; %in m, calculated in SolidWorks
c2=0.09; %CORRECTED FROM MCE647 COORD SYST AND PARS
%(old c1 value)
%Dimensional parameters of link 3:
l3=0.527; %in m, overall length of L3, from knee joint to load cell on shoe
c3=0.32; %in m, distance from knee joint to L3 CG including shoe
%Rotary inertia of link 2:
I2z=0.105+0.33;%in kg-m^2, includes green plate, threaded rod and connecting hardware.
%Rotary inertia of link 3:
I3z=0.0618; %in kg-m^2, overall inertia of L3 with shoe, relative to cm
g=9.81; %acceleration of gravity, m/s^2

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

TH1= m1+m2+m3;
TH2= m3*l2+m2*l2+m2*c2;
TH3= c3*m3;
TH4= I2z + I3z + c2^2*m2 + c3^2*m3 + l2^2*m2 + l2^2*m3 + 2*c2*l2*m2;
TH5= l2*m3*c3;
TH6= m3*c3^2 + I3z;
TH7= b;
TH8= f;

% Convert everything to symbolic with specified number of significant digits
NumDigits = 5;
m1 = vpa(m1, NumDigits);
m2 = vpa(m2, NumDigits);
m3 = vpa(m3, NumDigits);
f = vpa(f, NumDigits);
b = vpa(f, NumDigits);
l2 = vpa(l2, NumDigits);
c2 = vpa(c2, NumDigits);
l3 = vpa(l3, NumDigits);
c3 = vpa(c3, NumDigits);
I2z = vpa(I2z, NumDigits);
I3z = vpa(I3z, NumDigits);
g = vpa(g, NumDigits);
TH1 = vpa(TH1, NumDigits);
TH2 = vpa(TH2, NumDigits);
TH3 = vpa(TH3, NumDigits);
TH4 = vpa(TH4, NumDigits);
TH5 = vpa(TH5, NumDigits);
TH6 = vpa(TH6, NumDigits);
TH7 = vpa(TH7, NumDigits);
TH8 = vpa(TH8, NumDigits);
zero = vpa(0, NumDigits);

M(1,1)=TH1;
M(1,2)=TH3*cos(q2 + q3) + TH2*cos(q2);
M(1,3)=TH3*cos(q2 + q3);
M(2,1)=M(1,2);
M(2,2)=TH4 + 2*TH5*cos(q3);
M(2,3)=TH6 + TH5*cos(q3);
M(3,1)=M(1,3);
M(3,2)=M(2,3);
M(3,3)=TH6;

C(1,1)=zero;
C(1,2)=-q2dot*(TH3*sin(q2 + q3)+TH2*sin(q2))-TH3*q3dot*sin(q2 + q3);
C(1,3)=- TH3*q2dot*sin(q2 + q3) - TH3*q3dot*sin(q2 + q3);
C(2,1)=zero;
C(2,2)=-TH5*q3dot*sin(q3);
C(2,3)=- TH5*q2dot*sin(q3) - TH5*q3dot*sin(q3);
C(3,1)=zero;
C(3,2)=TH5*q2dot*sin(q3);
C(3,3)=zero;

gg=[-g*TH1;-g*(TH2*cos(q2)+TH3*cos(q2+q3));-g*TH3*cos(q2+q3)];

%External force terms
Te=[fez; fez*(l3*cos(q2+q3)+l2*cos(q2))-fex*(l3*sin(q2+q3)+l2*sin(q2));l3*(fez*cos(q2+q3)-fex*sin(q2+q3))];

%R=[TH8*sign(q1dot);TH7*q2dot;zero];
sign_q1dot = (1 - exp(-10*q1dot)) / (1 + exp(-10*q1dot));
R = [TH8*sign_q1dot ; TH7*q2dot ; zero];

f1 = q1dot;
f2 = q2dot;
f3 = q3dot;

syms m11 m12 m13 m21 m22 m23 m31 m32 m33 detM
M = [m11, m12, m13; m21, m22, m23; m31, m32, m33];
Minv = adjoint(M) / detM;
f456 = Minv*(u-R-C*qdot-gg-Te);
f4 = f456(1);
f5 = f456(2);
f6 = f456(3);

F(1,1) = diff(f1, q1);
F(1,2) = diff(f1, q2);
F(1,3) = diff(f1, q3);
F(1,4) = diff(f1, q1dot);
F(1,5) = diff(f1, q2dot);
F(1,6) = diff(f1, q3dot);

F(2,1) = diff(f2, q1);
F(2,2) = diff(f2, q2);
F(2,3) = diff(f2, q3);
F(2,4) = diff(f2, q1dot);
F(2,5) = diff(f2, q2dot);
F(2,6) = diff(f2, q3dot);

F(3,1) = diff(f3, q1);
F(3,2) = diff(f3, q2);
F(3,3) = diff(f3, q3);
F(3,4) = diff(f3, q1dot);
F(3,5) = diff(f3, q2dot);
F(3,6) = diff(f3, q3dot);

F(4,1) = diff(f4, q1);
F(4,2) = diff(f4, q2);
F(4,3) = diff(f4, q3);
F(4,4) = diff(f4, q1dot);
F(4,5) = diff(f4, q2dot);
F(4,6) = diff(f4, q3dot);

F(5,1) = diff(f5, q1);
F(5,2) = diff(f5, q2);
F(5,3) = diff(f5, q3);
F(5,4) = diff(f5, q1dot);
F(5,5) = diff(f5, q2dot);
F(5,6) = diff(f5, q3dot);

F(6,1) = diff(f6, q1);
F(6,2) = diff(f6, q2);
F(6,3) = diff(f6, q3);
F(6,4) = diff(f6, q1dot);
F(6,5) = diff(f6, q2dot);
F(6,6) = diff(f6, q3dot);

end

